package choucair.empleos.navegar.steps;

import choucair.empleos.navegar.pageobjects.NavegarEmpleosPageObject;
import net.thucydides.core.annotations.Step;

public class NavegarEmpleoStep {
	

	NavegarEmpleosPageObject  navegarempleopageobject;
	@Step 
	public void abrirurlchoucair() {
		navegarempleopageobject.open();
		// TODO Auto-generated method stub
		
	}
	@Step
	public void seleccionarempleos() {
		navegarempleopageobject.clicempleos();
		// TODO Auto-generated method stub
		
	}
	@Step
	public void validaropcionempleos() throws InterruptedException {
		navegarempleopageobject.clicportalempleo();
		// TODO Auto-generated method stub
		
	}

}
