package choucair.empleos.navegar.pageobjects;
import org.openqa.selenium.By;
public enum ElementChoucair {
	BOTON_EMPLEOS(By.xpath("//li/a[contains(text(),'Empleos')]")),
	LABEL_PREGUNTA(By.xpath("//*[@id='content']/div/div/div/div/div/section[2]/div/div/div[1]/div/div/div/div/div/div/h3/a")),
	LABEL_PREPARESE(By.xpath("//*[@id='content']/div/div/div/div/div/section[2]/div/div/div[2]/div/div/div/div/div/div/h3")),
	BOTON_PORTAL(By.xpath("/html/body/div[2]/div[3]/div/div/div/div/div/section[3]/div/div/div[2]/div/div/div/div/div/a")),
	;
	
	private By pValor;
	ElementChoucair(By pValor){
		this.pValor = pValor;
	} 
	public By getpValor() {
		return pValor;
	}

}
