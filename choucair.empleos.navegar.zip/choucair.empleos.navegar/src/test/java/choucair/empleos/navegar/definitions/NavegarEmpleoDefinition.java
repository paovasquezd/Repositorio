package choucair.empleos.navegar.definitions;

import choucair.empleos.navegar.steps.NavegarEmpleoStep;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class NavegarEmpleoDefinition {
	@Steps
	NavegarEmpleoStep navegarempleostep;
	
	@Given("^Dado que carga la pagina$")
	public void dado_que_carga_la_pagina() {
		navegarempleostep.abrirurlchoucair();
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
	}


	@When("^cuando ingreso a empleos$")
	public void cuando_ingreso_a_empleos() {
		navegarempleostep.seleccionarempleos();
	    // Write code here that turns the phrase above into concrete actions
	//    throw new PendingException();
	}

	@Then("^valido la opcion ir al portal de empleos$")
	public void valido_la_opcion_ir_al_portal_de_empleos() throws InterruptedException {
		navegarempleostep.validaropcionempleos();
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
	}
}
