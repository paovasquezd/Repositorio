package choucair.empleos.navegar.pageobjects;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;
@DefaultUrl("https://www.choucairtesting.com/")
public class NavegarEmpleosPageObject extends PageObject{

	static By BOTON_EMPLEOS = ElementChoucair.BOTON_EMPLEOS.getpValor();
	static By LABEL_PREGUNTA = ElementChoucair.LABEL_PREGUNTA.getpValor();
	static By LABEL_PREPARESE = ElementChoucair.LABEL_PREPARESE.getpValor();
	static By BOTON_PORTAL = ElementChoucair.BOTON_PORTAL.getpValor();
	public void clicempleos() {
		if(find(BOTON_EMPLEOS).isVisible()) {
			find(BOTON_EMPLEOS).click();
		}
		// TODO Auto-generated method stub
		
	}
		

	public void clicportalempleo() throws InterruptedException {
		desplazarPixelAbajo(getDriver());
		if(find(BOTON_PORTAL).isVisible()) {
			find(BOTON_PORTAL).click();
			Thread.sleep(2000);
		}
		// TODO Auto-generated method stub
		
	}
	
	public static void desplazarPixelAbajo(WebDriver driver) throws InterruptedException {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,150)");
		Thread.sleep(500);
	}
	
	
}
